#!/bin/bash
cd /home/ec2-user/server
sudo yum install java-1.8.0-openjdk -y
